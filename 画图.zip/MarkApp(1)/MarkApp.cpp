// SVGApp.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"

#include "MMarkFactory.h"

int _tmain(int argc, _TCHAR* argv[])
{
	//return 0;

	MMarkFactory::CreateMark_010101();
	MMarkFactory::CreateMark_010102();
	MMarkFactory::CreateMark_61();
	MMarkFactory::CreateMark_62();
	MMarkFactory::CreateMark_65();
	MMarkFactory::CreateMark_67();
	MMarkFactory::CreateMark_68();
	MMarkFactory::CreateMark_70();
	MMarkFactory::CreateMark_71();
	MMarkFactory::CreateMark_72();
	MMarkFactory::CreateMark_73();
	MMarkFactory::CreateMark_74();
	MMarkFactory::CreateMark_75();
	MMarkFactory::CreateMark_76();
	MMarkFactory::CreateMark_77();
	MMarkFactory::CreateMark_79();
	MMarkFactory::CreateMark_63();
}

