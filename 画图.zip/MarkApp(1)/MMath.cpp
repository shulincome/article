#include "stdafx.h"
#include "MMath.h"


MMath::MMath()
{
}


MMath::~MMath()
{
}
