#include "stdafx.h"
#include "MGeom.h"


MGeom::MGeom()
{
}


MGeom::~MGeom()
{
}
