#include "stdafx.h"
#include "MMark.h"


MMark::MMark()
{
}

MMark::MMark(string code) : m_sCode(code)
{

}


MMark::~MMark()
{

}





